# THE LAST CHECK-IN — SMALL ZIP HANDOFF

These ZIPs are small chunks of the 127-file **WIP** art-and-audio distribution. All parts must be extracted into the SAME folder to reconstruct the entire source pack. Keep folder names intact.

The files are **NOT a GitHub-ready blind overwrite**. Compare `src/assets/` to `game/src/assets/` and use Codex to map/verify assets. The latest branch already contains five newer painted environments (`*-v2.webp`) that must take precedence over legacy WIP files.

1. Download all seven `Last_Check_In_Part_XX_*.zip` files.
2. Unzip them into a **single staging directory**, NOT straight into GitHub.
3. Read `ASSET_GAP_AUDIT.md` and `CODEX_TASK.md`.
4. Merge chosen assets carefully into `game/src/assets/` and update the game manifest. Keep the five new `*-v2.webp` images and the corresponding map entries.
5. Run game tests (`npm test`, `npm run build`, browser e2e, device QA).

Every one of the original 127 relative paths is included exactly once across seven ZIP files. `FILE_INDEX.json` maps exact paths to part numbers. `CHUNK_SHA256SUMS.txt` beside the ZIPs gives their SHA-256 checksums. The local build script verified each ZIP's integrity and the reconstructed file hashes.

Confirmed branch: https://github.com/kavemankai/Mobileshai/tree/assets/environment-pass-02

Use pack parts as **asset staging**, not proof that art and sound are final. More detail in `ASSET_GAP_AUDIT.md`.
