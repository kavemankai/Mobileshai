from PIL import Image,ImageFilter,ImageOps
import numpy as np,cv2
from pathlib import Path
source=Image.open('/mnt/data/a_detailed_comprehensive_game_art_asset_pack_pres.png').convert('RGB')
coords={
'nina_neutral':(108,452,213,513),'nina_frightened':(219,452,315,513),'nina_relieved':(327,452,429,513),
'claire_guarded':(108,529,213,594),'claire_grieving':(217,529,319,594),'claire_angry':(327,529,429,594),
'owen_evasive':(109,610,209,670),'owen_broken':(221,610,321,670),
'daniel_friendly':(108,677,213,730),'daniel_threatening':(218,677,320,730),
}
O=Path('/mnt/data/LCI_Art_Audio_v1/src/assets/portraits')
for k,box in coords.items():
 im=source.crop(box)
 rgb=np.array(im)
 R=rgb[:,:,0].astype(np.float32);G=rgb[:,:,1].astype(np.float32);B=rgb[:,:,2].astype(np.float32)
 h,w=R.shape
 # blue-dark background chromakey with a skin/clothing foreground model
 bluish=(B-R>7)&(B-G>2)
 graydark=(R<30)&(G<40)&(B<46)
 m=np.full((h,w),cv2.GC_PR_FGD,dtype=np.uint8)
 m[bluish|graydark]=cv2.GC_PR_BGD
 m[0:2,:]=cv2.GC_BGD;m[-2:,:]=cv2.GC_BGD
 m[:,0:2]=cv2.GC_BGD;m[:,-2:]=cv2.GC_BGD
 warm=(R-B>20)&(R-G>5)&(R>40)
 yy,xx=np.ogrid[:h,:w]
 inside=(xx>w*.22)&(xx<w*.81)&(yy>h*.05)&(yy<h*.91)
 m[warm&inside]=cv2.GC_FGD
 if not (m==cv2.GC_FGD).any():m[h//2,w//2]=cv2.GC_FGD
 try:
  bg=np.zeros((1,65),np.float64);fg=np.zeros((1,65),np.float64)
  cv2.grabCut(rgb,m,None,bg,fg,6,cv2.GC_INIT_WITH_MASK)
  alpha=np.where((m==cv2.GC_FGD)|(m==cv2.GC_PR_FGD),255,0).astype(np.uint8)
 except Exception as e:
  print('grabcut',k,e);alpha=np.where(bluish,0,255).astype(np.uint8)
 # Preserve largest connected body region; softly mask jagged cut boundaries.
 num,labels,stats,cent=cv2.connectedComponentsWithStats((alpha>0).astype(np.uint8),8)
 if num>1:
  order=np.argsort(stats[1:,4])[::-1]+1
  keep=order[:2]
  alpha=np.where(np.isin(labels,keep),255,0).astype(np.uint8)
 alpha=cv2.GaussianBlur(alpha,(3,3),.75)
 rgba=Image.fromarray(np.dstack([rgb,alpha]),'RGBA')
 rgba=ImageOps.contain(rgba,(760,760),Image.Resampling.LANCZOS)
 canvas=Image.new('RGBA',(800,800));x=(800-rgba.width)//2;y=800-rgba.height-10
 canvas.alpha_composite(rgba,(x,y))
 canvas.save(O/f'{k}.webp','WEBP',quality=93,method=4)
for k,v in [('nina','nina_neutral'),('claire','claire_guarded'),('owen','owen_evasive'),('daniel','daniel_friendly')]:
 (O/f'{k}.webp').write_bytes((O/f'{v}.webp').read_bytes())
print('Updated',len(coords),'mattes')
