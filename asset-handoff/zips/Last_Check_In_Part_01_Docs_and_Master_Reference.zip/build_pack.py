from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance, ImageOps
import os, math, random, json, zipfile, subprocess, shutil, textwrap
import numpy as np
from scipy.signal import lfilter

ROOT='/mnt/data/LCI_Art_Audio_v1'
OUT=f'{ROOT}/src/assets'
for sub in ['art','portraits','interactive','hidden','inventory','puzzles','cctv','audio/sfx','audio/ambience','audio/music','audio/stingers']:
 os.makedirs(f'{OUT}/{sub}',exist_ok=True)
random.seed(20261107)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONTB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def font(sz,bold=False): return ImageFont.truetype(FONTB if bold else FONT,sz)
scenes=['exterior','reception','security','service','corridor17','room17','yard','records','laundry']
cols=[0,175,345,514,684,852,1018,1186,1364,1536]
source=Image.open('/mnt/data/a_detailed_comprehensive_game_art_asset_pack_pres.png').convert('RGB')
large=Image.open('/mnt/data/The_Last_Check_In_Master_Art_Direction.png').convert('RGB')

# Scene composites have native game dimensions and faithfully preserve source board's art direction.
# Their low-resolution painterly sources mean they are work-in-progress scene stand-ins, not final production drawings.
def vignette(w,h):
 y,x=np.ogrid[:h,:w];u=((x-w*.50)/(w*.80))**2+((y-h*.49)/(h*.91))**2
 return np.uint8(np.clip(u*.58,0,.62)*255)

def scene_img(idx,w=1080,h=1920):
 left,right=cols[idx],cols[idx+1]
 crop=source.crop((left+5,220,right-4,379))
 # Source sits in a painterly atmospheric frame, preserving proportions despite phone portrait ratio.
 bg=ImageOps.fit(crop,(w,h),Image.Resampling.BICUBIC,centering=(.5,.5)).filter(ImageFilter.GaussianBlur(48))
 bg=ImageEnhance.Brightness(bg).enhance(.46)
 canvas=bg.convert('RGBA')
 face=ImageOps.fit(crop,(w,int(w*.96)),Image.Resampling.LANCZOS)
 face=ImageEnhance.Contrast(face).enhance(1.10)
 # Feather top/bottom edges so image blends into portrait-safe atmospheric crop.
 fh=face.height
 alpha=Image.new('L',(w,fh),0); ad=ImageDraw.Draw(alpha)
 for y in range(fh):
  a=int(255*min(1, y/90, (fh-1-y)/100))
  ad.line((0,y,w,y),fill=max(0,a))
 face.putalpha(alpha)
 ypos=(h-fh)//2 - 150
 canvas.alpha_composite(face,(0,ypos))
 # Subtle rain/film grain gives coherence across cropped concept material.
 draw=ImageDraw.Draw(canvas,'RGBA')
 rng=random.Random(900+idx)
 for i in range(110):
  x=rng.randrange(w); y=rng.randrange(h); length=rng.randrange(12,52)
  draw.line((x,y,x-7,y+length),fill=(140,174,187,rng.randrange(8,25)),width=1)
 ov=Image.new('RGBA',(w,h),(0,0,0,0));ov.putalpha(Image.fromarray(vignette(w,h),'L'))
 canvas=Image.alpha_composite(canvas,ov)
 return canvas.convert('RGB')

for i,key in enumerate(scenes):
 p=f'{OUT}/art/{key}.webp';
 if not os.path.exists(p): scene_img(i).save(p,'WEBP',quality=84,method=4)
# Title image: large source, rearranged vertically to accommodate headline overlay by game rather than baked text.
if not os.path.exists(f'{OUT}/art/exterior_title.webp'): scene_img(0).save(f'{OUT}/art/exterior_title.webp','WEBP',quality=84,method=4)
# Large concept panels for cross-check reference.
shutil.copy('/mnt/data/The_Last_Check_In_Master_Art_Direction.png',f'{ROOT}/MASTER_STYLE_REFERENCE.png')

# 10 expression portraits (extracted from the character bible with edge matte). SOURCE IS CONCEPT RESOLUTION.
# Exact crop coordinates within third board as drawn at 1536x1024.
portrait_coords={
'nina_neutral':(108,452,213,513), 'nina_frightened':(219,452,315,513),'nina_relieved':(327,452,429,513),
'claire_guarded':(108,529,213,594),'claire_grieving':(217,529,319,594),'claire_angry':(327,529,429,594),
'owen_evasive':(109,610,209,670),'owen_broken':(221,610,321,670),
'daniel_friendly':(108,677,213,730),'daniel_threatening':(218,677,320,730),
}
for key,xy in portrait_coords.items():
 if os.path.exists(f'{OUT}/portraits/{key}.webp'): continue
 crop=source.crop(xy)
 # Estimate foreground matte: preserve character using a softened oval/trapezoidal silhouette.
 cw,ch=crop.size
 crop=ImageOps.contain(crop,(760,800),Image.Resampling.LANCZOS)
 portrait=Image.new('RGBA',(800,800),(0,0,0,0))
 cropw,croph=crop.size
 x=(800-cropw)//2; y=800-croph-40
 portrait.paste(crop,(x,y))
 # Alpha mask along borders and lower cut; softer for drop-in half body overlays.
 a=Image.new('L',(800,800),0);ad=ImageDraw.Draw(a)
 ad.rounded_rectangle((x+12,y+4,x+cropw-12,y+croph-5),radius=75,fill=255)
 a=a.filter(ImageFilter.GaussianBlur(17))
 # avoid matte spill on truly transparent outside
 portrait.putalpha(a)
 portrait.save(f'{OUT}/portraits/{key}.webp','WEBP',quality=92,method=4)
# Compatibility with original base keys
for k,var in [('nina','nina_neutral'),('claire','claire_guarded'),('owen','owen_evasive'),('daniel','daniel_friendly')]:
 shutil.copy(f'{OUT}/portraits/{var}.webp',f'{OUT}/portraits/{k}.webp')

# Draw original vector objects on pixel-safe source images for two hidden-object stages
COLORS={'paper':(225,205,165,255),'ink':(57,46,40,255),'gold':(213,157,74,255),'red':(144,59,47,255)}
def paper(draw,center,w=150,h=190,rotate=0,kind='receipt'):
 x,y=center
 draw.rounded_rectangle((x-w//2+9,y-h//2+12,x+w//2+9,y+h//2+12),radius=7,fill=(0,0,0,60))
 draw.rounded_rectangle((x-w//2,y-h//2,x+w//2,y+h//2),radius=6,fill=(224,206,169,255),outline=(94,73,50,220),width=4)
 if kind=='receipt':
  draw.line((x-w//3,y-h//3,x+w//3,y-h//3),fill=(90,67,40,230),width=5)
  for j in range(5): draw.line((x-w//3,y-h//5+j*20,x+w//3-(j%2)*35,y-h//5+j*20),fill=(108,87,64,180),width=3)
 else:
  for j in range(6): draw.line((x-w//3,y-h//3+j*25,x+w//3-(j%3)*22,y-h//3+j*25),fill=(90,70,55,180),width=3)

def keyobj(draw,center):
 x,y=center
 draw.ellipse((x-28,y-35,x+28,y+21),outline=(224,174,81,255),width=12)
 draw.rounded_rectangle((x-7,y+20,x+8,y+88),radius=3,fill=(211,166,83,255))
 draw.rectangle((x+6,y+64,x+33,y+74),fill=(211,166,83,255))
 draw.rectangle((x+6,y+80,x+24,y+90),fill=(211,166,83,255))

def draw_tag(draw,x,y,text='17'):
 draw.rounded_rectangle((x-56,y-38,x+56,y+38),radius=12,fill=(180,133,72),outline=(246,202,128),width=3)
 draw.ellipse((x-43,y-7,x-26,y+10),fill=(48,52,52))
 draw.text((x-15,y-23),text,font=font(42,True),fill=(35,45,48))

hidden_cfg={
'level_02_reception': (1,[('receipt',(14,84)),('receipt',(85,12)),('receipt',(47,26)),('receipt',(76,71)),('key',(62,33)),('note',(40,58))]),
'level_14_records': (7,[('report',(72,22)),('claim',(27,47)),('request',(55,64)),('tape',(12,15)),('photo',(86,82))]),
}
for name,(idx,items) in hidden_cfg.items():
 if os.path.exists(f'{OUT}/hidden/{name}.webp'): continue
 w,h=1536,2048
 # reduce source visual strength and add dense desk/records items
 base=scene_img(idx,w,h).convert('RGBA')
 d=ImageDraw.Draw(base,'RGBA');r=random.Random(idx)
 # Clutter in off-target locations; physical items, not emoji glyphs.
 protected=[(x/100*w,y/100*h) for _,(x,y) in items]
 for q in range(95):
  x=r.randrange(65,w-65);y=r.randrange(140,h-160)
  if any((x-a)**2+(y-b)**2<170**2 for a,b in protected): continue
  typ=r.randrange(7)
  if typ<4:
   ww=r.randrange(36,120); hh=r.randrange(45,160)
   d.rectangle((x,y,x+ww,y+hh),fill=(r.randrange(75,148),r.randrange(58,116),r.randrange(42,95),180),outline=(220,185,130,80),width=2)
   d.line((x+10,y+10,x+ww-15,y+10),fill=(245,222,172,65),width=3)
  elif typ==4: d.ellipse((x,y,x+25,y+25),outline=(180,170,146,180),width=4)
  elif typ==5: d.line((x,y,x+r.randrange(50,130),y+r.randrange(-15,15)),fill=(190,187,161,200),width=7)
  else: d.rounded_rectangle((x,y,x+64,y+34),radius=5,fill=(34,42,44,210),outline=(130,115,83,180),width=2)
 # Paint large recognizable target objects as separate layers on exact target positions.
 for kind,(xp,yp) in items:
  x=int(xp/100*w); y=int(yp/100*h)
  if kind in ('receipt','report','claim','request'):paper(d,(x,y),w=125 if kind=='receipt' else 160,h=150 if kind=='receipt' else 235,kind='receipt' if kind=='receipt' else 'file')
  elif kind=='key':keyobj(d,(x,y))
  elif kind=='note':
   d.polygon([(x-100,y-60),(x+90,y-60),(x+95,y+100),(x-95,y+93)],fill=(229,204,93),outline=(113,95,37))
   d.line((x-70,y,x+60,y),fill=(87,75,39,200),width=5)
  elif kind=='tape':
   d.rounded_rectangle((x-105,y-62,x+105,y+62),radius=13,fill=(45,44,45),outline=(198,175,133),width=8)
   d.ellipse((x-65,y-39,x-4,y+36),fill=(142,137,110));d.ellipse((x+4,y-39,x+65,y+36),fill=(142,137,110))
  elif kind=='photo':
   paper(d,(x,y),w=176,h=232,kind='file');d.rectangle((x-63,y-78,x+64,y+65),fill=(71,76,68));d.ellipse((x-28,y-70,x+29,y-15),fill=(152,132,102));d.polygon([(x-55,y+54),(x+58,y+54),(x+28,y-14),(x-32,y-14)],fill=(82,94,96))
 base.convert('RGB').save(f'{OUT}/hidden/{name}.webp','WEBP',quality=91,method=4)

# Escape room scenes use unlabelled visual affordances and 4:5 phone composition.
escape=[('level_05_service',3,['fuse','alcove','door','bucket','reader']),('level_09_corridor17',4,['door','mat','cart','board','ice','keypad']),('level_10_room17',5,['drawer','window','mattress','bin','bath','vent']),('level_23_laundry',8,['tag','basket','clipboard','extinguisher','door','keypad'])]
for name,idx,props in escape:
 if os.path.exists(f'{OUT}/interactive/{name}.webp'): continue
 w,h=1536,1920;base=scene_img(idx,w,h).convert('RGBA');d=ImageDraw.Draw(base,'RGBA')
 # Staged foreground physical objects; underlying original concept art retained.
 for j,prop in enumerate(props):
  x=int((.12+(j%3)*.37)*w);y=int((.18+(j//3)*.43)*h)
  if prop in ('fuse','reader','keypad'):
   d.rounded_rectangle((x-84,y-117,x+84,y+117),radius=12,fill=(64,74,77,235),outline=(142,136,109,255),width=9)
   for k in range(6):
    xx=x-50+(k%3)*49;yy=y-54+(k//3)*50
    d.rounded_rectangle((xx,yy,xx+26,yy+24),radius=4,fill=(21,36,41,255),outline=(170,178,167),width=3)
  elif prop in ('door','bath'):
   d.rectangle((x-135,y-220,x+135,y+220),fill=(71,58,48,210),outline=(184,141,90,240),width=13)
   d.ellipse((x+70,y,x+104,y+34),fill=(218,166,91,255))
  elif prop=='basket':
   d.polygon([(x-120,y-50),(x+120,y-50),(x+95,y+125),(x-90,y+125)],fill=(98,82,65,240),outline=(195,163,108,250))
   for yy in range(y-25,y+125,25):d.line((x-98,yy,x+98,yy),fill=(201,176,131,90),width=5)
  elif prop=='clipboard':paper(d,(x,y),w=166,h=260,kind='file')
  elif prop=='tag':draw_tag(d,x,y,'64')
  elif prop=='extinguisher':
   d.rounded_rectangle((x-40,y-105,x+40,y+120),radius=24,fill=(160,43,38,240),outline=(250,191,131),width=6)
   d.line((x,y-105,x+58,y-155),fill=(132,136,115),width=12)
  elif prop in ('board','mat','vent'):
   d.rounded_rectangle((x-125,y-105,x+125,y+105),radius=5,fill=(69,68,54,220),outline=(197,177,129),width=8)
   for yy in range(y-60,y+70,28):d.line((x-95,yy,x+95,yy),fill=(172,163,134,175),width=4)
  elif prop=='drawer':d.rectangle((x-135,y-70,x+135,y+90),fill=(95,68,46,245),outline=(188,128,77),width=8);d.ellipse((x-15,y+5,x+15,y+35),fill=(192,157,80))
  elif prop=='cart':
   d.rectangle((x-110,y-150,x+110,y+90),fill=(77,87,84,230),outline=(185,180,154),width=6)
   for xx in [x-65,x+65]:d.ellipse((xx-22,y+80,xx+22,y+125),fill=(18,28,31),outline=(197,183,145),width=6)
  elif prop=='ice':d.rectangle((x-95,y-150,x+95,y+125),fill=(101,112,116,245),outline=(184,192,188),width=6)
  elif prop=='bucket':d.polygon([(x-85,y-15),(x+85,y-15),(x+50,y+115),(x-45,y+115)],fill=(57,87,94,230),outline=(156,183,188))
  elif prop=='window':d.rectangle((x-120,y-165,x+120,y+105),fill=(24,54,68,220),outline=(156,117,81),width=14)
  elif prop=='mattress':d.rounded_rectangle((x-150,y-65,x+150,y+100),radius=24,fill=(172,149,123,220))
  elif prop=='bin':d.ellipse((x-80,y-70,x+80,y-15),fill=(107,110,98),outline=(193,180,146),width=5);d.polygon([(x-80,y-40),(x+80,y-40),(x+45,y+100),(x-45,y+100)],fill=(73,82,82))
  else:paper(d,(x,y),w=136,h=170,kind='file')
 base.convert('RGB').save(f'{OUT}/interactive/{name}.webp','WEBP',quality=90,method=4)

# Inventory assets: crisp, transparent, original rendered icon geometry
for name in ['torch','screwdriver','coin_50c','gloves']:
 s=256;im=Image.new('RGBA',(s,s));d=ImageDraw.Draw(im,'RGBA')
 if name=='torch':
  d.polygon([(68,45),(118,45),(132,88),(163,190),(104,216),(76,104)],fill=(91,94,88),outline=(225,193,124))
  d.ellipse((61,34,127,92),fill=(221,180,94),outline=(255,229,152),width=7)
  d.ellipse((80,51,110,78),fill=(252,238,172))
 elif name=='screwdriver':
  d.rounded_rectangle((110,70,149,215),radius=15,fill=(176,77,47),outline=(242,167,106),width=5)
  d.polygon([(116,70),(143,70),(136,15),(121,15)],fill=(167,176,175),outline=(241,235,200))
  for y in range(109,188,22):d.line((116,y,144,y),fill=(66,44,38),width=5)
 elif name=='coin_50c':
  pts=[(128+85*math.cos(math.pi*i/6),128+85*math.sin(math.pi*i/6)) for i in range(12)]
  d.polygon(pts,fill=(165,158,138),outline=(246,230,179));d.ellipse((68,68,189,189),outline=(224,209,160),width=7)
  d.text((84,103),'50',font=font(48,True),fill=(61,66,66))
 elif name=='gloves':
  for dx in [-35,35]:
   x=128+dx
   d.rounded_rectangle((x-40,95,x+38,222),radius=24,fill=(160,122,74),outline=(232,191,133),width=6)
   for finger in range(4):d.rounded_rectangle((x-35+finger*20,54,x-20+finger*20,137),radius=9,fill=(160,122,74),outline=(232,191,133),width=3)
 im.save(f'{OUT}/inventory/{name}.png')

# Puzzle skins: high-resolution original UI backgrounds with physical materials and 5 sprites for match3.
puzz={
'zip_path':('JUNCTION / RELAY BOARD',(31,53,57),(89,163,169)),
'box_cabinet':('SECURITY / CABINET',(63,57,46),(180,138,85)),
'box_switchboard':('SWITCHBOARD',(39,48,47),(177,157,99)),
'box_toolcase':('CONTRACTOR CASE',(43,46,50),(203,165,106)),
'box_gate':('SAFETY GATE',(65,53,43),(213,137,78)),
'panels':('CAMERA / FEED',(25,37,46),(113,165,181)),
'match3':('DAMAGED RECORDING',(38,48,56),(99,155,171)),
'timeline':('EVIDENCE / TIMELINE',(83,65,49),(217,184,127)),
'logic':('CROSS REFERENCE',(71,71,61),(192,177,145)),
'cryptex':('ARCHIVE CYLINDER',(54,43,28),(210,162,91)),
'goods':('STAFF KEYCARD RACK',(45,57,61),(160,177,158)),
'water':('FILTRATION TANKS',(43,50,48),(121,180,194)),
'blockfit':('RESTORED LEDGER',(76,64,52),(206,179,127)),
'tilt':('VALVE / MAZE',(34,55,54),(162,183,136)),
'hidden':('EVIDENCE SEARCH',(63,55,44),(173,143,100)),
'room':('INTERACTIVE SEARCH',(45,52,56),(177,172,133))}
for name,(label,basecol,accent) in puzz.items():
 if os.path.exists(f'{OUT}/puzzles/{name}.webp'): continue
 w=h=1024;im=Image.new('RGBA',(w,h),basecol+(255,));d=ImageDraw.Draw(im,'RGBA');rng=random.Random(sum(map(ord,name)))
 # 1mm industrial surface grain and light scuffs
 for i in range(18000):
  x=rng.randrange(w);y=rng.randrange(h);l=rng.randrange(1,16)
  d.line((x,y,x+l,y),fill=(255,255,235,rng.randrange(2,20)),width=1)
 for i in range(13):
  y=35+i*78;d.line((38,y,984,y),fill=accent+(35,),width=3)
 for x,y in [(32,32),(992,32),(32,992),(992,992)]:
  d.ellipse((x-15,y-15,x+15,y+15),fill=(20,23,23,220),outline=accent+(190,),width=4)
  d.line((x-6,y+7,x+7,y-5),fill=accent+(140,),width=3)
 d.rounded_rectangle((75,80,949,225),radius=13,fill=(5,13,18,115),outline=accent+(130,),width=4)
 d.text((105,117),label,font=font(58,True),fill=accent+(245,))
 # decorative board elements are intended as CSS skin; transparent UI elements remain on top.
 if name in ['box_cabinet','box_switchboard','box_toolcase','box_gate','cryptex']:
  for x in range(158,924,150):
   d.ellipse((x-23,870,x+23,916),fill=(28,29,30),outline=accent,width=6)
 im.save(f'{OUT}/puzzles/{name}.webp','WEBP',quality=87,method=4)
for j,c in enumerate([(175,76,61),(73,136,167),(182,158,69),(103,151,107),(142,100,156)],1):
 im=Image.new('RGBA',(256,256));d=ImageDraw.Draw(im,'RGBA')
 d.rounded_rectangle((12,12,244,244),radius=34,fill=c+(255,),outline=(249,229,188),width=8)
 d.rounded_rectangle((29,31,227,225),radius=27,outline=(37,51,60,120),width=6)
 if j==1:d.ellipse((77,69,179,175),outline=(246,236,205),width=19)
 elif j==2:d.polygon([(128,50),(207,187),(49,187)],fill=(241,226,187))
 elif j==3:d.rounded_rectangle((66,75,192,182),radius=18,fill=(236,225,183))
 elif j==4:
  for dx in [-38,38]:d.ellipse((128+dx-20,105,128+dx+20,155),fill=(239,226,175))
 else:d.line((66,65,190,191),fill=(240,229,193),width=26);d.line((190,65,66,191),fill=(240,229,193),width=26)
 im.save(f'{OUT}/puzzles/match_tile_{j}.png')

# Eight surveillance pieces x wide/close with cinematic scanline and timestamps. Level 4/13 swap backgrounds.
cam=source.crop((1035,450,1180,730))
for i in range(1,9):
 for zoom in ['wide','close']:
  if os.path.exists(f'{OUT}/cctv/panel_{i:02}_{zoom}.webp'): continue
  w,h=(960,540) if zoom=='wide' else (960,960)
  # select different subsegment of CCTV reference, with fallback original source; output is original composite study
  cx=1035+((i-1)%2)*75;cy=459+((i-1)//2%4)*65
  small=source.crop((cx,cy,cx+69,cy+59))
  im=ImageOps.fit(small,(w,h),Image.Resampling.BICUBIC)
  im=ImageEnhance.Color(im).enhance(.25)
  im=ImageEnhance.Contrast(im).enhance(1.15)
  d=ImageDraw.Draw(im,'RGBA')
  for yy in range(0,h,5):d.line((0,yy,w,yy),fill=(0,8,13,32),width=2)
  d.rectangle((16,16,w-16,h-16),outline=(94,146,165,200),width=3)
  d.text((34,32),f'CAM {i:02}',font=font(34,True),fill=(215,236,232))
  im.save(f'{OUT}/cctv/panel_{i:02}_{zoom}.webp','WEBP',quality=87,method=4)

# Contact sheet for handoff and inspection.
thumbs=[]
for key in scenes:
 im=Image.open(f'{OUT}/art/{key}.webp').convert('RGB'); thumb=ImageOps.fit(im,(200,350),Image.Resampling.LANCZOS)
 thumbs.append(thumb)
contact=Image.new('RGB',(1170,925),(12,23,31));d=ImageDraw.Draw(contact)
for i,img in enumerate(thumbs):
 x=20+(i%5)*230;y=35+(i//5)*450
 contact.paste(img,(x,y));d.text((x,y+358),scenes[i].upper(),font=font(21,True),fill=(237,210,163))
contact.save(f'{ROOT}/SCENE_CONTACT_SHEET.jpg',quality=88)

manifest={'source':'Generated original master concept boards + programmatic compositing','status':'visual draft assets only, NOT final hand-painted source resolution','format':'WebP/PNG','scenes':{k:f'art/{k}.webp' for k in scenes},'title':'art/exterior_title.webp','portraits':{k:f'portraits/{k}.webp' for k in portrait_coords},'hidden':list(hidden_cfg),'escape':[x[0] for x in escape],'cctv_count':16,'puzzle_skins':list(puzz),'inventory':['torch','screwdriver','coin_50c','gloves']}
with open(f'{ROOT}/ART_MANIFEST.json','w') as f:json.dump(manifest,f,indent=2)
print('ART DONE',len(scenes),'scenes',len(portrait_coords),'expressions',len(hidden_cfg),'hidden',len(escape),'rooms',len(puzz),'puzzle skins')
