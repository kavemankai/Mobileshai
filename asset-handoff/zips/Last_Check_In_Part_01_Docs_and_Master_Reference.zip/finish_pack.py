from pathlib import Path
from PIL import Image
import os, json, zipfile, subprocess, collections, html
ROOT=Path('/mnt/data/LCI_Art_Audio_v1');AS=ROOT/'src/assets'
scenes=['exterior','reception','security','service','corridor17','room17','yard','records','laundry']
chars={'NINA':'nina_neutral','CLAIRE':'claire_guarded','OWEN':'owen_evasive','DANIEL':'daniel_friendly'}
expressions=['nina_neutral','nina_frightened','nina_relieved','claire_guarded','claire_grieving','claire_angry','owen_evasive','owen_broken','daniel_friendly','daniel_threatening']
sfx=['tap','pick','place','swap','invalid','solve','clue','power','door','paper','metal','click','static','phone','pour','clear','combo','roll','ratchet','latch','chapter','found']
music=['title','investigation','tension','pressure','resolution'];stingers=['clue_found','chapter_end','nina_voice']
# Drop-in manifest with assets imported through Vite's static import analysis.
lines=['// Draft replacement for game/src/assets/manifest.ts.\n// Import the art/audio and adjust consumers for new types as documented.\n','import type { SceneKey } from \'../core/types\';\n']
for s in scenes: lines.append(f"import scene_{s} from './art/{s}.webp';\n")
lines.append("import title_art from './art/exterior_title.webp';\n")
for s in expressions: lines.append(f"import portrait_{s} from './portraits/{s}.webp';\n")
for s in sfx: lines.append(f"import sfx_{s} from './audio/sfx/{s}.m4a';\n")
for s in scenes: lines.append(f"import amb_{s} from './audio/ambience/{s}.m4a';\n")
for s in music: lines.append(f"import mus_{s} from './audio/music/{s}.m4a';\n")
for s in stingers:lines.append(f"import sting_{s} from './audio/stingers/{s}.m4a';\n")
lines+=['\nexport const SCENE_ART: Partial<Record<SceneKey,string>> = {\n']+[f'  {s}: scene_{s},\n' for s in scenes]+['};\n','export const TITLE_ART: string | null = title_art;\n','export const PORTRAITS: Record<string,string> = {\n']
for k,v in chars.items():lines.append(f'  {k}: portrait_{v},\n')
for s in expressions:lines.append(f'  {s.upper()}: portrait_{s},\n')
lines.append('};\n')
lines.append('export const AUDIO_FILES: Record<string,string> = {\n')
for s in sfx:lines.append(f'  {s}: sfx_{s},\n')
lines.append('};\n')
lines.append('export const AMBIENCE_FILES: Record<string,string> = {\n')
for s in scenes:lines.append(f'  {s}: amb_{s},\n')
lines.append('};\n')
lines.append('export const MUSIC_FILES: Record<string,string> = {\n')
for s in music:lines.append(f'  {s}: mus_{s},\n')
lines.append('};\n')
lines.append('export const STINGER_FILES: Record<string,string> = {\n')
for s in stingers:lines.append(f'  {s}: sting_{s},\n')
lines.append('};\n\n')
lines.append('// Retain the existing SCENE_PLACEHOLDER constant from the original manifest\n// if src/core/art.ts still imports it. Do not remove it without updating that consumer.\n')
(ROOT/'MANIFEST_DRAFT.ts').write_text(''.join(lines))

readme='''# THE LAST CHECK-IN — ART + AUDIO PASS v1

Source target: `kavemankai/Mobileshai` / `game/` on the 7 Nov 2026 reviewed branch.

## What has actually been produced

- 9 1080×1920 WebP scene compositions plus a title variant.
- 10 expression portrait drafts as 800×800 WebP with alpha matte; four base-name compatibility files.
- 2 hidden-object compositions at 1536×2048, with object affordances at the percentage positions documented in `game/ASSETS.md`.
- 4 interactive-room compositions at 1536×1920; **object placements are approximate**, not yet checked against exact hotspot rectangles.
- 16 CCTV panel crops (eight IDs, wide and close), stylized with scan lines.
- 4 inventory icons (256×256 PNG alpha); source brief asks 128×128 and these can be downscaled losslessly for in-game use.
- 16 material board skins and 5 match-tile sprites.
- 22 short synthesised original effects, 9 synthesised location ambience loops, 5 original synthesized musical underscore loops and 3 stingers, all AAC/M4A; total audio < 3 MiB.
- `MANIFEST_DRAFT.ts`, browser preview and automated QA asset report.

## Important quality limitations

**The still artwork is an interim visual-development pass, not full-resolution final art.** Some images derive from the original image-generation concept boards; these were composites, so the extracted source panels are small. They have been upscaled, extended for portrait framing and processed. Any text or fine objects inside the crops may be soft or inaccurate. These should be replaced with true individually generated/painted environment illustrations before release.

Character extracts have an approximate feathered alpha matte. Hair and clothing edges are not final. Room props were drawn at approximated positions. CCTV images are composited variants and are **not** the exact bespoke match-edge illustrations required for the Gorogoa-like panel mechanic; that final artwork remains outstanding. Puzzle skin images are generic background textures and **do not supply separately animated pieces** such as levers, latches or hardware layers.

The audio files are generated by original procedural synthesis, **not recorded foley or a commissioned score**. They can be integrated for an audible first pass, but quality and subjective mixing need phone testing. No third-party sound samples were used.

## Integration procedure for Codex

1. Copy `src/assets/` from this ZIP into the repository's `game/src/assets/`, preserving relative paths.
2. Use `MANIFEST_DRAFT.ts` as a starting point when editing `game/src/assets/manifest.ts`. **Preserve `SCENE_PLACEHOLDER`** until `game/src/core/art.ts` no longer needs it.
3. The existing `SCENE_ART`, `TITLE_ART`, `PORTRAITS` and `AUDIO_FILES` keys are compatible in principle. Verify the actual build and asset bundler imports.
4. For facial expressions, change `portraitFor` in `game/src/core/art.ts` so a speaker tag such as `NINA · FRIGHTENED` selects `NINA_FRIGHTENED` first, then falls back to `NINA`. Update speaker tags as needed, without affecting narrative text.
5. Add `AMBIENCE_FILES`, `MUSIC_FILES` and `STINGER_FILES` consumption in `src/core/audio.ts`. Music/ambience should crossfade, respect the user's volume settings, pause when the tab is hidden and remain unlocked until user gesture. Do not start overlapping autoplay streams.
6. In the hidden-object game (`src/puzzles/hidden.ts`), hide existing emoji glyph overlays only **after checking that every painted target is accurately aligned with the clickable hit region**. Keep the accessibility labels available.
7. In the escape-room game (`src/puzzles/room.ts`), validate all hotspots and item interaction rectangles against the illustration at the actual phone viewport. Do **not** set `PROPS_VISIBLE=false` before the locations match. Replace placeholders with transparent hotspot overlays after alignment.
8. Assign custom skins through CSS or per-puzzle backgrounds where appropriate. Keep touch hit boxes at least 44 CSS px and never put vital UI under notches/nav bars.
9. Verify CCTV panel art visual continuity. Replace the draft crops with purpose-drawn panels before calling those two levels art-complete.
10. Run the existing `npm test`, `npm run build`, `npm run build:single`, `npm run e2e`, and manual Android touch/audio/offline tests. Preserve developer title-seven-taps, `?debug=1`, DEV skip and jump-to-level sandbox behavior.

## Sound integration

All SFX original names referenced in `game/ASSETS.md` are present. The provided music and ambience filenames are also in the manifest draft, but the engine still needs explicit new routing. Avoid playing downloaded music at full scale under spoken or written dialogue. Use simple equal-power crossfades and user-adjustable music/sfx/ambience bus volumes.

## License / provenance

All generated image content comes from asset boards produced specifically for this project in this ChatGPT conversation. Other raster overlays and all audio are created procedurally for this task. This pack includes no external stock assets or samples. No unrelated third-party licenses are required for the generated material in the package; external replacements should be logged with their individual licenses.

## Ship-quality blockers

- Individual, detailed 9:16 painted scenes at genuine source resolution (currently reference-extracted upscale).
- Clean character cutouts at 800 px+ genuine source resolution, matching lighting.
- Game-accurate layered hotspot scenes and independently animated mechanism sprites.
- Eight bespoke Gorogoa-style illustrated panels with edge-joining compositions (and their close-up variants).
- Real-world foley and final music/ambience mixing if aiming for commercial polish.
- End-to-end integration into the GitHub codebase and real Android QA. The GitHub repository has **not** been modified by this package build.
'''
(ROOT/'README.md').write_text(readme)
(ROOT/'CODEX_TASK.md').write_text('''# Codex: import and finish the Last Check-In asset pass

Read `README.md`, `ART_MANIFEST.json`, `AUDIO_MANIFEST.json` and the actual repository's `game/ASSETS.md` + `The_Last_Check_In/OVERHAUL_REVIEW.md`.

Treat everything in `src/assets/` as a **WIP implementation batch** with known reference-crop limitations, not approved final production artwork.

1. Integrate the nine environment image files and base portrait variants via `manifest.ts`.
2. Integrate all 22 audio feedback effects, location ambience, five score cues and three stingers without regressions; ensure user-gesture audio unlock and correct ducking.
3. Integrate the two hidden-object and four escape-room drafts only after hotspot-by-hotspot alignment. Keep the test overlay on during validation.
4. Add/replace puzzle board skins and sprites without changing solver rules.
5. Turn the reference composites into genuine independently authored high-resolution art, using `MASTER_STYLE_REFERENCE.png` and the nine-scene contact sheet as the visual anchor. Prioritize room interactions and CCTV bespoke art before calling the art pass finished.
6. Maintain all 28 levels, hint/skip behavior, saved progression, PWA offline support, portrait mobile layout and the dev debug mode.
7. Run npm tests and real-device quality checks. Provide screenshots, test results, asset audit, and list any remaining placeholder assets.

Do not claim everything is final just because files exist at the target dimensions.
''')

# Browser asset index for zipped extracted viewing
css='''body{margin:0;background:#091823;color:#e5d8c1;font:15px system-ui,sans-serif}header{padding:26px;background:#152b38}h1{font-size:28px;margin:0 0 8px}h2{margin:28px 0 8px}main{max-width:1120px;margin:auto;padding:20px}p{color:#a7bbc2;max-width:780px}.gallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:14px}.tile{background:#19303b;border:1px solid #324c55;border-radius:10px;overflow:hidden;padding:8px}.tile img{width:100%;object-fit:cover;border-radius:6px}.tile span{display:block;padding:7px;font-size:12px}.tile audio{width:100%}'''
body=['<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LCI Asset Pack Review</title>',f'<style>{css}</style>','<header><h1>The Last Check-In — Asset Pack v1</h1><div>Visual drafts, interactive art and synthetic original audio</div></header><main><p>Preview only. Extract the ZIP to keep file paths available. Most visual assets are concept-board-based drafts and require full-resolution re-authoring before release.</p>']
for title,paths in [('Environments',[f'art/{s}.webp' for s in scenes]),('Portraits',[f'portraits/{s}.webp' for s in expressions]),('Hidden-object scenes',['hidden/level_02_reception.webp','hidden/level_14_records.webp']),('Escape rooms',[f'interactive/{s}.webp' for s in ['level_05_service','level_09_corridor17','level_10_room17','level_23_laundry']]),('Puzzle skin samples',[f'puzzles/{s}.webp' for s in ['zip_path','box_cabinet','match3','cryptex','timeline','tilt']])]:
 body.append('<h2>'+title+'</h2><div class="gallery">')
 for path in paths: body.append(f'<div class="tile"><img loading="lazy" src="src/assets/{path}"><span>{html.escape(path)}</span></div>')
 body.append('</div>')
for title,paths in [('Music',[f'music/{s}' for s in music]),('Stingers',[f'stingers/{s}' for s in stingers]),('Ambient loops',[f'ambience/{s}' for s in scenes]),('SFX',[f'sfx/{s}' for s in sfx])]:
 body.append('<h2>'+title+'</h2><div class="gallery">')
 for path in paths:body.append(f'<div class="tile"><span>{path}</span><audio controls preload="none" src="src/assets/audio/{path}.m4a"></audio></div>')
 body.append('</div>')
body.append('</main></html>')
(ROOT/'PREVIEW.html').write_text(''.join(body))

# Objective QA: counts, dimension checks, audio decoding inspection.
qa=[]
for rel,expected in [('art/'+s+'.webp',(1080,1920)) for s in scenes]+[('art/exterior_title.webp',(1080,1920))]+ [('portraits/'+s+'.webp',(800,800)) for s in expressions]+ [('interactive/'+s+'.webp',(1536,1920)) for s in ['level_05_service','level_09_corridor17','level_10_room17','level_23_laundry']]+ [('hidden/'+s+'.webp',(1536,2048)) for s in ['level_02_reception','level_14_records']]:
 p=AS/rel;exists=p.is_file();size=Image.open(p).size if exists else None
 qa.append({'file':str(rel),'valid':exists and size==expected,'resolution':size,'expected':expected})
from subprocess import run,PIPE
for p in (AS/'audio').rglob('*.m4a'):
 z=run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(p)],capture_output=True,text=True)
 qa.append({'file':str(p.relative_to(AS)),'valid':z.returncode==0 and float(z.stdout or '0')>0,'duration_seconds':round(float(z.stdout or '0'),2)})
summary=collections.Counter(p.parent.name for p in AS.rglob('*') if p.is_file())
report={'summary':dict(summary),'valid':all(q['valid'] for q in qa),'checks':qa,'warning':'Visual resolution dimensions pass, but native source resolution and hotspot matching are not QA-approved.'}
(ROOT/'QA_ASSET_REPORT.json').write_text(json.dumps(report,indent=2))
# Zip complete handoff, exclude build programs which remain in source folder as optional reproducibility tools.
zipname='/mnt/data/The_Last_Check_In_Art_Audio_WIP_Pack_v1.zip'
with zipfile.ZipFile(zipname,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in ROOT.rglob('*'):
  if p.is_file() and p.name not in ['scene_row.png','people.png','puzzles.png']:
   z.write(p,p.relative_to(ROOT))
print('ZIP',zipname,round(os.path.getsize(zipname)/1024**2,2),'MiB','QA',report['valid'],'file counts',dict(summary))
