# Codex: import and finish the Last Check-In asset pass

Read `README.md`, `ART_MANIFEST.json`, `AUDIO_MANIFEST.json` and the actual repository's `game/ASSETS.md` + `The_Last_Check_In/OVERHAUL_REVIEW.md`.

Treat everything in `src/assets/` as a **WIP implementation batch** with known reference-crop limitations, not approved final production artwork.

1. Integrate the nine environment image files and base portrait variants via `manifest.ts`.
2. Integrate all 22 audio feedback effects, location ambience, five score cues and three stingers without regressions; ensure user-gesture audio unlock and correct ducking.
3. Integrate the two hidden-object and four escape-room drafts only after hotspot-by-hotspot alignment. Keep the test overlay on during validation.
4. Add/replace puzzle board skins and sprites without changing solver rules.
5. Turn the reference composites into genuine independently authored high-resolution art, using `MASTER_STYLE_REFERENCE.png` and the nine-scene contact sheet as the visual anchor. Prioritize room interactions and CCTV bespoke art before calling the art pass finished.
6. Maintain all 28 levels, hint/skip behavior, saved progression, PWA offline support, portrait mobile layout and the dev debug mode.
7. Run npm tests and real-device quality checks. Provide screenshots, test results, asset audit, and list any remaining placeholder assets.

Do not claim everything is final just because files exist at the target dimensions.
