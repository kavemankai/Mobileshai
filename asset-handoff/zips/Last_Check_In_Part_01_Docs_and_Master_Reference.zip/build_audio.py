import os,math,random,subprocess,tempfile,json
import numpy as np
from scipy.signal import butter,sosfilt
from scipy.io import wavfile
ROOT='/mnt/data/LCI_Art_Audio_v1/src/assets/audio'
for sub in ['sfx','ambience','music','stingers']: os.makedirs(f'{ROOT}/{sub}',exist_ok=True)
SR=22050
rng=np.random.default_rng(21006)
def tvec(sec):return np.arange(int(SR*sec),dtype=np.float64)/SR
def decay(n,sec=.15):return np.exp(-np.arange(n)/SR/(sec+.0001))
def sin(f,t,phase=0):return np.sin(2*np.pi*f*t+phase)
def noise(length,lo=0,hi=None):
 a=rng.normal(0,1,int(SR*length))
 if hi:
  sos=butter(3,[lo,hi],btype='bandpass',fs=SR,output='sos')
 elif lo:sos=butter(3,lo,btype='lowpass',fs=SR,output='sos')
 else:return a
 return sosfilt(sos,a)
def fade(a,d=.04):
 n=len(a); k=min(int(SR*d),n//3)
 if k:a[:k]*=np.linspace(0,1,k);a[-k:]*=np.linspace(1,0,k)
 return a
def normalize(a,peak=.72):
 a=np.asarray(a,np.float64);peakcurrent=np.max(abs(a))
 if peakcurrent>0:a*=peak/max(peakcurrent,1e-7)
 return a
def save(rel,a,rate='64k'):
 path=f'{ROOT}/{rel}.m4a'
 wav=path+'.wav'; a=normalize(a, .68)
 wavfile.write(wav,SR,(np.clip(a,-1,1)*32760).astype(np.int16))
 p=subprocess.run(['ffmpeg','-loglevel','error','-y','-i',wav,'-c:a','aac','-b:a',rate,'-ar',str(SR),path],capture_output=True,text=True)
 os.remove(wav)
 if p.returncode:raise Exception(p.stderr)
 return path

def impulse(sec,f=700,dec=.05,noiselevel=.3):
 t=tvec(sec)
 return sin(f,t)*np.exp(-t/dec)+noiselevel*noise(sec,1900,8500)*np.exp(-t/max(.012,dec*.5))
def sequence(duration,items):
 arr=np.zeros(int(SR*duration))
 for at,sig,gain in items:
  st=int(at*SR);en=min(len(arr),st+len(sig));arr[st:en]+=sig[:en-st]*gain
 return arr

def sfx(name):
 dur={'tap':.13,'pick':.26,'place':.27,'swap':.45,'invalid':.34,'solve':1.15,'clue':1.04,'power':1.34,'door':1.25,'paper':.64,'metal':.8,'click':.18,'static':.55,'phone':1.1,'pour':1.28,'clear':.62,'combo':1.3,'roll':.8,'ratchet':.58,'latch':.84,'chapter':1.6,'found':.72}[name]
 t=tvec(dur)
 if name=='tap':a=impulse(dur,970,.017,.16)
 elif name=='pick':a=impulse(dur,455,.06,.18)+impulse(dur,890,.04,.06)*.25
 elif name=='place':a=impulse(dur,255,.08,.31)
 elif name=='swap':a=sequence(dur,[(0,impulse(.14,380,.04,.20),1),(.18,impulse(.14,540,.05,.18),1)])
 elif name=='invalid':a=sin(205,t)*np.exp(-t/0.16)+.23*sin(154,t)*np.exp(-t/0.15)
 elif name=='solve':a=sum((.22*sin(293.66*(2**(k/12)),t)*np.exp(-np.maximum(t-.16*i,0)/(.35+0.07*i))*(t>.16*i) for i,k in enumerate([0,4,7,12])))
 elif name=='clue':a=.5*sin(415,t)*np.exp(-t/.41)+.37*sin(622,t)*np.exp(-np.maximum(t-.16,0)/.28)*(t>.16)
 elif name=='power':a=(.4*sin(55+100*t,t)*np.minimum(1,t/.3)+.15*noise(dur,900,3800))*np.minimum(1,t/.25)
 elif name=='door':a=.25*noise(dur,250,2100)*(np.exp(-t/.38))+.6*sin(114,t)*np.exp(-t/.28)+sequence(dur,[(.55,impulse(.5,150,.15,.5),1)])
 elif name=='paper':a=noise(dur,1300,7000)*(.23+.31*np.abs(sin(6,t)))*np.exp(-t/.5)
 elif name=='metal':a=impulse(dur,680,.29,.53)+.35*sin(1310,t)*np.exp(-t/.45)
 elif name=='click':a=impulse(dur,1350,.028,.15)
 elif name=='static':a=noise(dur,300,6900)*(.4+.4*np.abs(sin(65,t)))*np.exp(-t/.8)
 elif name=='phone':a=.43*(sin(410,t)+.55*sin(445,t))*(.5+.5*np.sign(sin(3.0,t)))*np.exp(-t/.9)
 elif name=='pour':a=.45*noise(dur,250,2600)*(.2+.8*np.sin(np.pi*np.minimum(1,t/dur))**2)+.2*sin(130+20*t,t)
 elif name=='clear':a=impulse(dur,700,.15,.18)+.35*sin(990,t)*np.exp(-t/.18)
 elif name=='combo':a=sequence(dur,[(k*.18,impulse(.27,450+140*k,.1,.25),.7) for k in range(5)])
 elif name=='roll':a=.17*noise(dur,500,2500)*(np.maximum(0,np.sin(37*t)))*np.exp(-t/.6)+.25*sin(120,t)*np.exp(-t/.35)
 elif name=='ratchet':a=sequence(dur,[(k*.065,impulse(.11,1200,.025,.3),.75) for k in range(7)])
 elif name=='latch':a=impulse(dur,270,.24,.5)+sequence(dur,[(.2,impulse(.35,475,.11,.2),.7)])
 elif name=='chapter':a=sum((sin(f,t)*np.exp(-t/.95)*w for f,w in [(146.8,.28),(220,.20),(293.66,.17),(440,.12)]))
 elif name=='found':a=sequence(dur,[(0,impulse(.18,510,.08,.13),1),(.17,impulse(.3,850,.16,.1),1)])
 return fade(np.tanh(a),.012)

names=['tap','pick','place','swap','invalid','solve','clue','power','door','paper','metal','click','static','phone','pour','clear','combo','roll','ratchet','latch','chapter','found']
for name in names:save('sfx/'+name,sfx(name),'64k')

# Location ambience: independent layered loops with smooth circular fade. Originally synthesized; licensed recordings can replace these later.
def amb(kind,dur=18):
 t=tvec(dur)
 n=noise(dur,1600,9000)
 low=noise(dur,50,700)
 mid=noise(dur,240,2100)
 waves=.06*sin(.19,t)+.09*sin(.31,t)
 if kind=='exterior':a=.28*n+.14*low+.2*waves+.09*sin(59,t)
 elif kind=='reception':a=.14*n+.08*low+.12*sin(51,t)+.11*waves
 elif kind=='security':a=.1*n+.18*low+.12*sin(80,t)+.08*sin(124,t)
 elif kind=='service':a=.11*n+.17*low+.12*mid+.1*sin(49,t)
 elif kind=='corridor17':a=.13*n+.12*mid+.09*sin(64,t)+.09*waves
 elif kind=='room17':a=.2*n+.1*mid+.16*waves
 elif kind=='yard':a=.25*n+.19*low+.13*waves
 elif kind=='records':a=.06*n+.1*low+.05*mid+.05*sin(60,t)
 elif kind=='laundry':a=.11*n+.25*low+.2*sin(55,t)+.13*mid
 # distant texture details
 for k in range(14):
  start=int(rng.uniform(0,dur-.6)*SR);size=int(rng.uniform(.04,.42)*SR)
  bump=np.tanh(rng.normal(size=size)*.25)
  a[start:start+size]+=bump*.02
 # crossfade circular ends over 1.1s for continuous loop
 k=int(SR*1.1)
 z=a.copy()
 a[-k:]=z[-k:]*(1-np.linspace(0,1,k))+z[:k]*np.linspace(0,1,k)
 return a

for name in ['exterior','reception','security','service','corridor17','room17','yard','records','laundry']:
 save('ambience/'+name,amb(name),'56k')

# Original non-copyright ambient motif. Slow minor/major-tone underscore for unobtrusive thriller story.
# Separate cues have distinct harmonic/melodic trajectories and intentional pacing.
def pad(freq,t,attack=.7,release=2.5):
 # mild beating and rich harmonics without hard oscillator buzz
 return (sin(freq,t)+.23*sin(freq*2,t+.2)+.11*sin(freq*.5,t))*(.67+.33*sin(.13,t)**2)
def music(kind,dur=32):
 t=tvec(dur);a=np.zeros_like(t)
 chordroot={'title':146.83,'investigation':130.81,'tension':123.47,'pressure':110,'resolution':164.81}[kind]
 shape={'title':[0,3,7],'investigation':[0,3,7,10],'tension':[0,1,6],'pressure':[0,3,6],'resolution':[0,4,7,12]}[kind]
 # 8-second harmonic cycles, with a subtle repeating melody, avoiding distracting strong percussion
 for seg in range(4):
  lo=int(seg*dur/4*SR);hi=int((seg+1)*dur/4*SR);ss=t[lo:hi]-(seg*dur/4)
  root=chordroot * (1 if seg in (0,3) else 2**(([5,-2][seg-1])/12))
  env=np.sin(np.pi*np.clip(ss/(dur/4),0,1))**.65
  for degree in shape:
   f=root*2**(degree/12)
   a[lo:hi]+=.15*pad(f,ss)*env
  if kind!='tension':
   for q in range(4):
    start=int((seg*dur/4+q*dur/16)*SR)
    length=min(int(SR*2.4),len(a)-start)
    tt=np.arange(length,dtype=np.float64)/SR
    note=root*2**(shape[(q+seg)%len(shape)]/12)*2
    a[start:start+length]+=.11*(sin(note,tt)+.16*sin(note*2,tt))*np.exp(-tt/1.15)
 if kind=='pressure':
  for q in range(55):
   j=int((q*.56)*SR);length=min(int(.2*SR),len(a)-j)
   if length>0:a[j:j+length]+=.12*sin(62,np.arange(length,dtype=np.float64)/SR)*np.exp(-np.arange(length)/SR/.072)
 if kind=='tension':a+=.11*noise(dur,200,900)*np.sin(np.pi*t/dur)
 # subtle air bed and edge-safe loop crossfade
 a+=.045*noise(dur,400,1700)
 k=int(SR*.7);end=a[-k:].copy();beg=a[:k].copy()
 a[-k:]=end*(1-np.linspace(0,1,k))+beg*np.linspace(0,1,k)
 return a
for name in ['title','investigation','tension','pressure','resolution']:
 save('music/'+name,music(name),'80k')
for name,notes in [('clue_found',[220,329.63,440]),('chapter_end',[146.83,220,293.66]),('nina_voice',[349.23,440,659.25])]:
 t=tvec(2.4)
 a=sum(.23*sin(f,t+k*.15)*np.exp(-np.maximum(t-.2*k,0)/.67)*(t>=.2*k) for k,f in enumerate(notes))
 save('stingers/'+name,fade(a,.045),'72k')

items=[]
for dirpath,dirs,files in os.walk(ROOT):
 for file in files:
  if not file.endswith('.m4a'):continue
  path=os.path.join(dirpath,file)
  items.append({'path':os.path.relpath(path,ROOT),'bytes':os.path.getsize(path)})
with open('/mnt/data/LCI_Art_Audio_v1/AUDIO_MANIFEST.json','w') as f:json.dump(items,f,indent=2)
print('Audio produced:',len(items),'files',round(sum(x['bytes'] for x in items)/1024**2,2),'MiB')
