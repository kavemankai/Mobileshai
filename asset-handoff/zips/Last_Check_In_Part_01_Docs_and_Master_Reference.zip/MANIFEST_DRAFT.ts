// Draft replacement for game/src/assets/manifest.ts.
// Import the art/audio and adjust consumers for new types as documented.
import type { SceneKey } from '../core/types';
import scene_exterior from './art/exterior.webp';
import scene_reception from './art/reception.webp';
import scene_security from './art/security.webp';
import scene_service from './art/service.webp';
import scene_corridor17 from './art/corridor17.webp';
import scene_room17 from './art/room17.webp';
import scene_yard from './art/yard.webp';
import scene_records from './art/records.webp';
import scene_laundry from './art/laundry.webp';
import title_art from './art/exterior_title.webp';
import portrait_nina_neutral from './portraits/nina_neutral.webp';
import portrait_nina_frightened from './portraits/nina_frightened.webp';
import portrait_nina_relieved from './portraits/nina_relieved.webp';
import portrait_claire_guarded from './portraits/claire_guarded.webp';
import portrait_claire_grieving from './portraits/claire_grieving.webp';
import portrait_claire_angry from './portraits/claire_angry.webp';
import portrait_owen_evasive from './portraits/owen_evasive.webp';
import portrait_owen_broken from './portraits/owen_broken.webp';
import portrait_daniel_friendly from './portraits/daniel_friendly.webp';
import portrait_daniel_threatening from './portraits/daniel_threatening.webp';
import sfx_tap from './audio/sfx/tap.m4a';
import sfx_pick from './audio/sfx/pick.m4a';
import sfx_place from './audio/sfx/place.m4a';
import sfx_swap from './audio/sfx/swap.m4a';
import sfx_invalid from './audio/sfx/invalid.m4a';
import sfx_solve from './audio/sfx/solve.m4a';
import sfx_clue from './audio/sfx/clue.m4a';
import sfx_power from './audio/sfx/power.m4a';
import sfx_door from './audio/sfx/door.m4a';
import sfx_paper from './audio/sfx/paper.m4a';
import sfx_metal from './audio/sfx/metal.m4a';
import sfx_click from './audio/sfx/click.m4a';
import sfx_static from './audio/sfx/static.m4a';
import sfx_phone from './audio/sfx/phone.m4a';
import sfx_pour from './audio/sfx/pour.m4a';
import sfx_clear from './audio/sfx/clear.m4a';
import sfx_combo from './audio/sfx/combo.m4a';
import sfx_roll from './audio/sfx/roll.m4a';
import sfx_ratchet from './audio/sfx/ratchet.m4a';
import sfx_latch from './audio/sfx/latch.m4a';
import sfx_chapter from './audio/sfx/chapter.m4a';
import sfx_found from './audio/sfx/found.m4a';
import amb_exterior from './audio/ambience/exterior.m4a';
import amb_reception from './audio/ambience/reception.m4a';
import amb_security from './audio/ambience/security.m4a';
import amb_service from './audio/ambience/service.m4a';
import amb_corridor17 from './audio/ambience/corridor17.m4a';
import amb_room17 from './audio/ambience/room17.m4a';
import amb_yard from './audio/ambience/yard.m4a';
import amb_records from './audio/ambience/records.m4a';
import amb_laundry from './audio/ambience/laundry.m4a';
import mus_title from './audio/music/title.m4a';
import mus_investigation from './audio/music/investigation.m4a';
import mus_tension from './audio/music/tension.m4a';
import mus_pressure from './audio/music/pressure.m4a';
import mus_resolution from './audio/music/resolution.m4a';
import sting_clue_found from './audio/stingers/clue_found.m4a';
import sting_chapter_end from './audio/stingers/chapter_end.m4a';
import sting_nina_voice from './audio/stingers/nina_voice.m4a';

export const SCENE_ART: Partial<Record<SceneKey,string>> = {
  exterior: scene_exterior,
  reception: scene_reception,
  security: scene_security,
  service: scene_service,
  corridor17: scene_corridor17,
  room17: scene_room17,
  yard: scene_yard,
  records: scene_records,
  laundry: scene_laundry,
};
export const TITLE_ART: string | null = title_art;
export const PORTRAITS: Record<string,string> = {
  NINA: portrait_nina_neutral,
  CLAIRE: portrait_claire_guarded,
  OWEN: portrait_owen_evasive,
  DANIEL: portrait_daniel_friendly,
  NINA_NEUTRAL: portrait_nina_neutral,
  NINA_FRIGHTENED: portrait_nina_frightened,
  NINA_RELIEVED: portrait_nina_relieved,
  CLAIRE_GUARDED: portrait_claire_guarded,
  CLAIRE_GRIEVING: portrait_claire_grieving,
  CLAIRE_ANGRY: portrait_claire_angry,
  OWEN_EVASIVE: portrait_owen_evasive,
  OWEN_BROKEN: portrait_owen_broken,
  DANIEL_FRIENDLY: portrait_daniel_friendly,
  DANIEL_THREATENING: portrait_daniel_threatening,
};
export const AUDIO_FILES: Record<string,string> = {
  tap: sfx_tap,
  pick: sfx_pick,
  place: sfx_place,
  swap: sfx_swap,
  invalid: sfx_invalid,
  solve: sfx_solve,
  clue: sfx_clue,
  power: sfx_power,
  door: sfx_door,
  paper: sfx_paper,
  metal: sfx_metal,
  click: sfx_click,
  static: sfx_static,
  phone: sfx_phone,
  pour: sfx_pour,
  clear: sfx_clear,
  combo: sfx_combo,
  roll: sfx_roll,
  ratchet: sfx_ratchet,
  latch: sfx_latch,
  chapter: sfx_chapter,
  found: sfx_found,
};
export const AMBIENCE_FILES: Record<string,string> = {
  exterior: amb_exterior,
  reception: amb_reception,
  security: amb_security,
  service: amb_service,
  corridor17: amb_corridor17,
  room17: amb_room17,
  yard: amb_yard,
  records: amb_records,
  laundry: amb_laundry,
};
export const MUSIC_FILES: Record<string,string> = {
  title: mus_title,
  investigation: mus_investigation,
  tension: mus_tension,
  pressure: mus_pressure,
  resolution: mus_resolution,
};
export const STINGER_FILES: Record<string,string> = {
  clue_found: sting_clue_found,
  chapter_end: sting_chapter_end,
  nina_voice: sting_nina_voice,
};

// Retain the existing SCENE_PLACEHOLDER constant from the original manifest
// if src/core/art.ts still imports it. Do not remove it without updating that consumer.
